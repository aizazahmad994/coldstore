package com.example.coldstore.AdapterClasses;

public class EntriesAdapter {
}
