package com.example.coldstore.AdapterClasses;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.coldstore.R;
import com.example.coldstore.ModelClasses.UserInformation;
import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> {

    Context context;
    ArrayList<UserInformation> user_info;

    public UserAdapter(Context c , ArrayList<UserInformation> p)
    {
        context = c;
        user_info = p;
    }

    @Override
    public MyViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_view,parent,false));
    }

    @Override
    public void onBindViewHolder( MyViewHolder holder, int position) {
        holder.name.setText(user_info.get(position).getName());
        holder.phone.setText(user_info.get(position).getNumber());
        holder.address.setText(user_info.get(position).getAddress());
    }

    @Override
    public int getItemCount() {
        return user_info.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView name,phone,address;
        Button btn;
        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.naam);
            phone = (TextView) itemView.findViewById(R.id.mobail_no);
            address = (TextView) itemView.findViewById(R.id.pata);
            btn = (Button) itemView.findViewById(R.id.View_More);
                   }
        public void onClick(final int position)
        {
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, position+" is clicked", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
