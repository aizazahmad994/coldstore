package com.example.coldstore.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.coldstore.R;

public class AdminDashBoardActivity extends AppCompatActivity {

    ImageButton search;
    ImageButton add_record;
    ImageButton view_record, receipt;
    Button rec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        search = (ImageButton) findViewById(R.id.searchbutton);
        add_record = (ImageButton) findViewById(R.id.addrecordbutton);
        view_record = (ImageButton) findViewById(R.id.viewrecordbutton);
        rec = (Button) findViewById(R.id.rec);

        add_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), addRecord.class);
                startActivity(i);
            }
        });
        view_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), view.class);
                startActivity(i);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), search.class);
                startActivity(i);
            }
        });


        rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), rec.class);
                startActivity(i);
            }
        });
    }
}